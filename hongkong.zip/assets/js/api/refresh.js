const main = document.getElementById('main')
const info = document.getElementById('info')
const refresh = document.getElementById('refresh')
const refreshTimer = document.getElementById('refreshTimer')
const articleDiv = document.getElementById('articles')

// News APIs
const urlGuardian = 'https://content.guardianapis.com/search?order-by=newest&q=hong%20kong&api-key=1e075072-b9c5-41d7-9849-ad82dca2efeb'

let isAuto = false

var timer = 30

function setRefresh() {
	if(refresh.checked) {
		isAuto = true
		info.innerHTML = '<div class="alert alert-success" role="alert" id="refreshConfirm">\n<div class="container">\nAuto refresh enabled!\n<button type="button" class="close" data-dismiss="alert" aria-label="Close">\n<span aria-hidden="true">\n<i class="now-ui-icons ui-1_simple-remove"></i>\n</span>\n</button>\n</div>\n</div>'
		refreshStart()
	} else {
		isAuto = false
		info.innerHTML = '<div class="alert alert-warning" role="alert" id="refreshConfirm">\n<div class="container">\nAuto refresh disabled!\n<button type="button" class="close" data-dismiss="alert" aria-label="Close">\n<span aria-hidden="true">\n<i class="now-ui-icons ui-1_simple-remove"></i>\n</span>\n</button>\n</div>\n</div>'
		refreshTimer.innerHTML = ""
		timer = 30
	}
}

function refreshStart() {
	if (isAuto) {
		if (timer > 0) {
			refreshTimer.innerHTML = 'Refreshing in <span class="badge badge-primary">' + timer + '</span> seconds.'
			timer--
			setTimeout(refreshStart, 1000);
		} else {
			timer = 30
			callGuardian()
			refreshStart()
		}
	} else {
		return
	}
}

function clearInfo() {
	info.innerHTML = ""
}

function callGuardian() {
	// reset articleDiv and put a loading icon
	articleDiv.innerHTML = "<p>Loading...</p>"
	fetch(urlGuardian)
		.then(response => response.json())
		.then(function(response) {
			// get rid of the loading text
			articleDiv.innerHTML = ""
			let articles = response.response.results
			articles.forEach(article => {
				let card = document.createElement('div')
				card.setAttribute('class', 'card')

				let cardDiv = document.createElement('div')
				cardDiv.setAttribute('class', 'card-body')

				let header = document.createElement('h3')
				header.setAttribute('class', 'card-title')
				header.innerHTML = '<strong>' + article.webTitle + '</strong>'

				let date = document.createElement('p')
				date.setAttribute('class', 'card-subtitle')
				date.textContent = article.webPublicationDate.substring(0, 10) + ' ' + article.webPublicationDate.substring(11, 19) + ' UTC'

				let linkTo = document.createElement('button')
				linkTo.setAttribute('class', 'btn btn-primary btn-round card-body')
				linkTo.setAttribute('type', 'button')
				linkTo.setAttribute('onclick', 'window.location.href = "' + article.webUrl + '"')
				linkTo.innerHTML = 'Link to article'

				cardDiv.append(header)
				cardDiv.append(date)
				cardDiv.append(linkTo)

				card.append(cardDiv)

				articleDiv.append(card)
			})
		})
}

window.onload(callGuardian())